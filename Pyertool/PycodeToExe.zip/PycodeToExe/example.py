print("this is an example")
a = input("Enter a number: ")
print("You entered:", a)